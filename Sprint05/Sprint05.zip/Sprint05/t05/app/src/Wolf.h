#pragma once

#include "Creature.h"

class Wolf : virtual public Creature {
public:
    Wolf() = default;
    ~Wolf() = default;
};