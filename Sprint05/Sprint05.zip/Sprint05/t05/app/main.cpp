#include "Werewolf.h"

int main() {
    Werewolf wolf;
    return 0;
}