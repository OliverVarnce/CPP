#pragma once

#include "Axe.h"
#include "ImperialSoldier.h"
#include <iostream>
#include "Solider.h"

class ImperialSoldier;

class StormcloakSoldier final : public Soldier {
public:
    StormcloakSoldier();
    ~StormcloakSoldier();
private:
    Axe* m_weapon;
    int m_health;
};
