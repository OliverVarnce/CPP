#pragma once

#include "Weapon.h"

class Axe final : public Weapon {
public: 
    Axe(int damage);
};
