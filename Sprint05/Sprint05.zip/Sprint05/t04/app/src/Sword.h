#pragma once

#include "Weapon.h"

class Sword final : public Weapon {
public:
    Sword(int damage);
};
