#include "Axe.h"

Axe::Axe(int damage) 
    : Weapon(damage) {}
